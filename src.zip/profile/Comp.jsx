import React from 'react'
import { useState } from 'react'
import './Comp.css'

export default function Comp() {
    const [count , setcount]=useState(0);

    let message;
    if (count>10 || count < 0 ){
       message=<h3>depassement de limite</h3>
    }
    else{
       message=<h3></h3>
    }
    
  return (
    <div>
        <h2>Counter : {count}</h2>
        {message}
        <button onClick={()=>setcount((prev)=>prev+1)}  className="button1">+</button>
        <button onClick={()=>setcount((prev)=>prev-1)}  className="button2">-</button>   
    </div>

    
  )
}